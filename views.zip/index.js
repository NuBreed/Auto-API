const express = require('express')
const app = express()
const CORS = require('cors')
const mongodb = require('mongodb')
const path = require('path')
const MongoClient = require('mongodb').MongoClient
app.use('*/css', express.static(path.join(__dirname + '/public/style.css')))

const url = 'mongodb://localhost:27017/Carly'
const client = new MongoClient(url)

const data = require('./data.json')
const { cursorTo } = require('readline')
app.use(CORS('http://127.0.0.1:5500/index.html'))

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'))
})

app.listen(8000, () => console.log('server started on 5000'))
